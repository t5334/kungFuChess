"""
KungFu Chess package.
""" 