"""
Test package for KungFu Chess.
""" 